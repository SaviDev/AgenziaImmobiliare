﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgenziaImmobiliare
{
    class Alloggi
    {
        private string provincia;
        private int prezzo;
        private int nAlloggi;

        public Alloggi()
        {
            provincia = "";
            prezzo = nAlloggi = 0;
        }
        public Alloggi(string s,int c,int g)
        {
            provincia = s;
            prezzo = c;
            nAlloggi = g;
        }
        public string GetProvincia()
        {
            return provincia;
        }
        public int GetPrezzo()
        {
            return prezzo;
        }
        public int GetNalloggi()
        {
            return nAlloggi;
        }
        public void SetProvincia(string s)
        {
            provincia = s;
        }
        public void SetPrezzo(int s)
        {
            prezzo = s;
        }
        public void SetNalloggi(int s)
        {
            nAlloggi = s;
        }

    }
}
