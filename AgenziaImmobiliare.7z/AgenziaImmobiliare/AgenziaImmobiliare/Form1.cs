﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgenziaImmobiliare
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

         Alloggi[] girasole = new Alloggi[3000];
         int contatore = 0;
        int cont = -1;
        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string provincia = textBox1.Text;
            provincia = provincia.ToLower();
            int prezzo = Convert.ToInt32(textBox2.Text);
            int nAlloggi = Convert.ToInt32(textBox3.Text);
            if (nAlloggi > 50)
            {
                MessageBox.Show("inserire alloggi minore di 50");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            else
            {
                contatore++;
                Array.Resize(ref girasole, contatore);
                girasole[contatore-1] = new Alloggi(provincia, prezzo, nAlloggi);              

                    if (contatore == 1)
                    {
                        StampaTodo(girasole, girasole.Length,false);
                    }
                    else
                    {
                        int y = 0;
                        for (int z = 0; z < girasole.Length - 1; z++)
                        {
                            for (y = 0; y < girasole.Length - 1; y++)
                            {
                                if (contatore > 1)
                                {
                                    string prima = Convert.ToString(girasole[y].GetProvincia());
                                    string dopo = Convert.ToString(girasole[y + 1].GetProvincia());
                                    SelectionSortProvincie(prima, dopo, ref y);
                                    if (y == 101)
                                    {
                                        break;
                                    }
                                }

                            }
                            for (int i = 0; i < girasole.Length; i++)
                            {
                                string s = girasole[i].GetProvincia();
                                for (int g = i + 1; g < girasole.Length; g++)
                                    if (girasole[g].GetProvincia() == s)
                                    {
                                        if (girasole[g].GetPrezzo() < girasole[i].GetPrezzo())
                                        {
                                            Alloggi appoggio = girasole[g];
                                            girasole[g] = girasole[i];
                                            girasole[i] = appoggio;
                                        }
                                        if (girasole[g].GetPrezzo() == girasole[i].GetPrezzo())
                                        {
                                            if (girasole[g].GetNalloggi() < girasole[i].GetNalloggi())
                                            {
                                                Alloggi appoggio = girasole[g];
                                                girasole[g] = girasole[i];
                                                girasole[i] = appoggio;
                                            }
                                        }
                                    }
                            }
                        }

                        StampaTodo(girasole, contatore,false);
                    }
                
                                  
                }
            }
             void SelectionSortProvincie(string prima,string dopo,ref int s)
            {
              //  for (int z = 0; z< ; z++)
              //  {
                    int uno = 0, due = 0;
                    for(int f = 0;f < prima.Length || f < dopo.Length; f++)
                    {
                         uno = Convert.ToInt32(Convert.ToChar(prima.Substring(f, 1)));
                         due = Convert.ToInt32(Convert.ToChar(dopo.Substring(f, 1)));
                if (uno > due)
                {
                    Alloggi appoggio = girasole[s];
                    girasole[s] = girasole[s + 1];
                    girasole[s + 1] = appoggio;
                    s = 101;
                    break;
                }
                if (uno == due)
                {

                }
                if(uno < due)
                {
                    break;
                }
            } 
                    
                    
               // }
            }

            void StampaTodo(Alloggi[] gir,int cont,bool vero)
            {
            if (cont >= 0 && vero == false)
            {
                dataGridView1.Rows.Add();
            }
                for(int i = 0; i < cont; i++)
                {
                    for (int s = 0; s < 3; s++)
                    {
                    if ( vero == true)
                    {
                        dataGridView1.Rows.Add();
                    }
                        if(s == 0)
                        {
                        string f = gir[i].GetProvincia();
                        dataGridView1.Rows[i].Cells[s].Value = f;
                        }
                        if (s == 1)
                        {
                            dataGridView1.Rows[i].Cells[s].Value = Convert.ToString(gir[i].GetPrezzo());

                        }
                        if (s == 2) 
                        {
                            dataGridView1.Rows[i].Cells[s].Value = Convert.ToString(gir[i].GetNalloggi());

                        }
                    }
                }
            }

        private void Button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            for (int i = 0;i < contatore; i++)
            {
                girasole[i].SetProvincia("");
                girasole[i].SetPrezzo(0);
                girasole[i].SetPrezzo(0);
                dataGridView1.Rows.Clear();
                contatore = 0;
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            string patto = @"C:\Users\Davide\Desktop\Scuola\Informatica\AgenziaImmobiliare\Testo.txt";
            //      File.Create(patto);

            using (StreamWriter txt = new StreamWriter(patto))
            {
                for(int i = 0;i < girasole.Length; i++)
                {
                    string s = girasole[i].GetProvincia() + "▓" + Convert.ToString(girasole[i].GetPrezzo()) + "@" + Convert.ToString(girasole[i].GetNalloggi());
                    txt.WriteLine(s);
                }
                
            }
        }
        string DammiProvincia(string s)
        {
            string z = "";
            for (int i = 0;s[i] != '▓'; i++)
            {
                z = z + Convert.ToString(s[i]);
            }
            return z;
        }
        string DammiPrezzo(string s)
        {
            string z = "";
            int i = s.IndexOf('▓', 0);
            for (i = i+1; s[i] != '@'; i++)
            {
                z = z + Convert.ToString(s[i]);
            }
            return z;
        }
        string NumeAlloggi(string s)
        {
            string z = "";
            int f = s.Length;
            int i = s.IndexOf('@', 0);
            for (i = i + 1; i < f; i++)
            {
                z = z + Convert.ToString(s[i]);
            }
            return z;
        }
        private void Button5_Click(object sender, EventArgs e)
        {
            string patto = @"C:\Users\Davide\Desktop\Scuola\Informatica\AgenziaImmobiliare\Testo.txt";
            using (StreamReader txt = new StreamReader(patto))
            
            {
                cont = -1;
                string line =  "";
                while((line = txt.ReadLine()) != null)
                {
                    cont ++;
                    Array.Resize(ref girasole, cont + 1);
                    string provincia = DammiProvincia(line);
                    int prezzo = Convert.ToInt32(DammiPrezzo(line));
                    string nAlloggi = NumeAlloggi(line);
                    girasole[cont] = new Alloggi(provincia, prezzo,Convert.ToInt32(nAlloggi));
                }
            }
            dataGridView1.Rows.Clear();
            cont = girasole.Length;
            Array.Resize(ref girasole, cont);
           // string s = girasole[2].GetProvincia();
            StampaTodo(girasole, cont,true);

            }
        }
    }

